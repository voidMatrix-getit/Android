package yash.multimedia

import android.annotation.SuppressLint
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.view.ContextMenu
import android.view.ContextMenu.ContextMenuInfo
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import yash.multimedia.R
import java.io.IOException

class Audio : AppCompatActivity() {
    private var tv: TextView? = null
    private var mp: MediaPlayer? = null
    private var audioUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_audio)

        tv = findViewById(R.id.tv)
        registerForContextMenu(tv)
    }

    override fun onCreateContextMenu(menu: ContextMenu, v: View, menuInfo: ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menuInflater.inflate(R.menu.audiomenu, menu)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        return try {
            playAudio(item.itemId)
        } catch (e: IOException) {
            throw RuntimeException(e)
        }
    }

    @SuppressLint("NewApi")
    @Throws(IOException::class)
    private fun playAudio(id: Int): Boolean {
        // Release the current MediaPlayer if it's not null
        mp?.let {
            it.release()
            mp = null
        }

        when (id) {
            R.id.pfr -> {
                // Play audio from raw resources
                mp = MediaPlayer.create(applicationContext, R.raw.avengersmainonend)
                mp?.start()
                return true
            }
            R.id.pfi -> {
                // Play internal storage audio
                audioUrl = "/data/data/yash.multimedia/avengersmainonend.mp3"
                play(audioUrl)
                return true
            }
            R.id.pfe -> {
                // Play external storage audio
                audioUrl = "/sdcard/avengersmainonend.mp3"
                play(audioUrl)
                return true
            }
            R.id.pfw -> {
                // Play web audio
                val audioUrl = "https://lost-plus-found.000webhostapp.com/dearmrfantasy.mp3"
                play(audioUrl)
                return true
            }
            R.id.pbp -> {
                // Pick audio from the device
                val intent = Intent(Intent.ACTION_PICK).apply {
                    type = "audio/*"
                }
                startActivityForResult(intent, 1)
                return true
            }
            else -> return false
        }
    }

    @Throws(IOException::class)
    private fun play(path: String?) {
        if (path == null) {
            Toast.makeText(this, "Audio path is null", Toast.LENGTH_SHORT).show()
            return
        }
        // Release the current MediaPlayer if it's not null
        mp?.release()

        mp = MediaPlayer().apply {
            setDataSource(path)
            prepare()
            start()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            data?.data?.let { audioUri ->
                try {
                    // Convert the URI to a file path and play the audio
                    val audioPath = getRealPathFromURI(audioUri)
                    if (audioPath != null) {
                        play(audioPath)
                    } else {
                        Toast.makeText(this, "Unable to get audio file path", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: IOException) {
                    e.printStackTrace()
                    Toast.makeText(this, "Error playing audio", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    private fun getRealPathFromURI(uri: Uri): String? {
        var path: String? = null
        val projection = arrayOf(android.provider.MediaStore.Audio.Media.DATA)
        val cursor = contentResolver.query(uri, projection, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val columnIndex = it.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DATA)
                path = it.getString(columnIndex)
            }
        }
        return path
    }

}
