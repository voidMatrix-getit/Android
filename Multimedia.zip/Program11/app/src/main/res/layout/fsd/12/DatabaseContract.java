package voidy.sahil.exercises.database;

import android.provider.BaseColumns;

public final class DatabaseContract {


    private DatabaseContract() {}

    public static class PlayerEntry implements BaseColumns {
        public static final String TABLE_NAME = "players";
        public static final String COLUMN_NAME_PLAYER_NAME = "player_name";
        public static final String COLUMN_NAME_LEVEL = "level";
        public static final String COLUMN_NAME_TROPHIES = "trophies";
        public static final String COLUMN_NAME_LEAGUE = "league";
        public static final String COLUMN_NAME_POSITION = "position";
        public static final String COLUMN_NAME_IS_ACTIVE = "is_active";
        public static final String COLUMN_NAME_GOLD = "gold";
    }
}
