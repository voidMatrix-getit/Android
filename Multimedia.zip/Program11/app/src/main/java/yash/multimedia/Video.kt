package yash.multimedia

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.MediaController
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import java.io.IOException

class Video : AppCompatActivity() {
    private lateinit var videoView: VideoView
    private var mediaController: MediaController? = null
    private var videoPath: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video)

        videoView = findViewById(R.id.vv)
        mediaController = MediaController(this)
        videoView.setMediaController(mediaController)

        registerForContextMenu(videoView)
    }

    override fun onCreateContextMenu(menu: ContextMenu, v: View, menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menuInflater.inflate(R.menu.videomenu, menu)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        return try {
            playVideo(item.itemId)
        } catch (e: IOException) {
            e.printStackTrace()
            false
        }
    }

    @SuppressLint("NewApi")
    @Throws(IOException::class)
    private fun playVideo(id: Int): Boolean {
        when (id) {
            R.id.pfrv -> videoPath = "android.resource://$packageName/${R.raw.civilwarclip}"
            R.id.pfiv -> videoPath = "/data/data/yash.multimedia/civilwarclip.mp4"
            R.id.pfev -> videoPath = "/sdcard/civilwarclip.mp4"
            R.id.pfwv -> videoPath = "https://lost-plus-found.000webhostapp.com/avengersassemble.mp4"
            R.id.pbpv -> {
                val intent = Intent(Intent.ACTION_PICK).apply { type = "video/*" }
                startActivityForResult(intent, 1)
                return true
            }
            else -> return false
        }
        videoPath?.let { play(it) }
        return true
    }

    private fun play(path: String) {
        val uri = Uri.parse(path)
        videoView.setVideoURI(uri)
        videoView.start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                videoView.setVideoURI(uri)
                videoView.start()
            }
        }
    }
}
