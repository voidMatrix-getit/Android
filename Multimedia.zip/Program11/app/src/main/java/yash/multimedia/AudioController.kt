package yash.multimedia

import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Button
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import yash.multimedia.R
import java.io.IOException

class AudioController : AppCompatActivity() {
    private var mediaPlayer: MediaPlayer? = null
    private lateinit var playButton: Button
    private lateinit var pauseButton: Button
    private lateinit var stopButton: Button
    private lateinit var resumeButton: Button
    private lateinit var forwardButton: Button
    private lateinit var backwardButton: Button
    private lateinit var seekBar: SeekBar
    private val mHandler = Handler()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_audio_controller)

        // Initialize MediaPlayer and buttons
        mediaPlayer = MediaPlayer()
        try {
            mediaPlayer?.setDataSource("/sdcard/avengersmainonend.mp3")
            mediaPlayer?.prepare()
        } catch (e: IOException) {
            throw RuntimeException(e)
        }

        playButton = findViewById(R.id.play_button)
        pauseButton = findViewById(R.id.pause_button)
        resumeButton = findViewById(R.id.resume_button)
        stopButton = findViewById(R.id.stop_button)
        forwardButton = findViewById(R.id.forward_button)
        backwardButton = findViewById(R.id.backward_button)
        seekBar = findViewById(R.id.seek_bar)

        // Play button logic
        playButton.setOnClickListener {
            mediaPlayer?.start()
            updateSeekBar()
        }

        // Pause button logic
        pauseButton.setOnClickListener {
            mediaPlayer?.pause()
        }

        // Resume button logic
        resumeButton.setOnClickListener {
            mediaPlayer?.start()
            updateSeekBar()
        }

        // Stop button logic
        stopButton.setOnClickListener {
            mediaPlayer?.apply {
                stop()
                reset()
                try {
                    setDataSource("/sdcard/avengersmainonend.mp3")
                    prepare()
                } catch (e: IOException) {
                    throw RuntimeException(e)
                }
            }
        }

        // Forward button logic (skip 5 seconds)
        forwardButton.setOnClickListener {
            mediaPlayer?.let {
                val newPosition = it.currentPosition + 5000
                if (newPosition < it.duration) {
                    it.seekTo(newPosition)
                } else {
                    it.seekTo(it.duration)
                }
            }
        }

        // Backward button logic (rewind 5 seconds)
        backwardButton.setOnClickListener {
            mediaPlayer?.let {
                val newPosition = it.currentPosition - 5000
                if (newPosition > 0) {
                    it.seekTo(newPosition)
                } else {
                    it.seekTo(0)
                }
            }
        }

        // SeekBar logic
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    mediaPlayer?.seekTo(progress)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {
                // No action needed
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                // No action needed
            }
        })
    }

    // Update SeekBar position
    private fun updateSeekBar() {
        seekBar.max = mediaPlayer?.duration ?: 0
        mHandler.postDelayed(object : Runnable {
            override fun run() {
                mediaPlayer?.let {
                    if (it.isPlaying) {
                        seekBar.progress = it.currentPosition
                    }
                }
                mHandler.postDelayed(this, 1000)
            }
        }, 1000)
    }

    override fun onDestroy() {
        super.onDestroy()
        // Release MediaPlayer resources
        mediaPlayer?.release()
        mediaPlayer = null
        mHandler.removeCallbacksAndMessages(null)
    }
}
