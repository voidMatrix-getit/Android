package voidy.sahil.exercises.database;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;
    ArrayAdapter<String> adapter;
    ArrayList<String> playerList;
    ListView listViewPlayers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        playerList = new ArrayList<>();
        listViewPlayers = findViewById(R.id.listViewPlayers);
        registerForContextMenu(listViewPlayers);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, playerList){
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView textView = (TextView) view.findViewById(android.R.id.text1);
                textView.setGravity(Gravity.CENTER);
                return view;
            }
        };
        listViewPlayers.setAdapter(adapter);
        loadPlayerData();

        Button addButton = findViewById(R.id.buttonAdd);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddPlayerDialog();
            }
        });

        listViewPlayers.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                showContextMenu(position);
                return true;
            }
        });
    }

    private void showContextMenu(int position) {


        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setTitle("Choose Action");
        dialogBuilder.setItems(new CharSequence[]{"Show", "Update", "Delete"}, (dialog, which) -> {
            switch (which) {
                case 0:
                    showPlayerDialog(playerList.get(position));
                    break;
                case 1:
                    showUpdatePlayerDialog(playerList.get(position));
                    break;
                case 2:
                    showConfirmDeleteDialog(playerList.get(position));
                    break;
            }
        });
        dialogBuilder.create().show();
    }

    private void loadPlayerData() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                DatabaseContract.PlayerEntry.COLUMN_NAME_PLAYER_NAME
        };
        Cursor cursor = db.query(
                DatabaseContract.PlayerEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null
        );
        playerList.clear();
        while (cursor.moveToNext()) {
            String playerName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.PlayerEntry.COLUMN_NAME_PLAYER_NAME));
            playerList.add(playerName);
        }
        adapter.notifyDataSetChanged();
        cursor.close();
    }

    private void showAddPlayerDialog() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.add_player_dialog, null);
        dialogBuilder.setView(dialogView);

        final EditText playerNameEditText = dialogView.findViewById(R.id.editTextPlayerName);
        final EditText levelEditText = dialogView.findViewById(R.id.editTextLevel);
        final EditText trophiesEditText = dialogView.findViewById(R.id.editTextTrophies);
        final EditText leagueEditText = dialogView.findViewById(R.id.editTextLeague);
        final EditText positionEditText = dialogView.findViewById(R.id.editTextPosition);
        final ToggleButton isActiveEditText = dialogView.findViewById(R.id.editTextIsActive);
        final EditText goldEditText = dialogView.findViewById(R.id.editTextGold);

        dialogBuilder.setTitle("Add Player");
        dialogBuilder.setPositiveButton("Add", null);
        dialogBuilder.setNegativeButton("Cancel", null);

        final AlertDialog dialog = dialogBuilder.create();
        dialog.setOnShowListener(dialogInterface -> {
            Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            positiveButton.setOnClickListener(view -> {
                String playerName = playerNameEditText.getText().toString().trim();
                if (!playerName.isEmpty()) {
                    insertPlayer(playerName,
                            Integer.parseInt(levelEditText.getText().toString()),
                            Integer.parseInt(trophiesEditText.getText().toString()),
                            leagueEditText.getText().toString(),
                            positionEditText.getText().toString(),
                            isActiveEditText.getText().toString(),
                            Double.parseDouble(goldEditText.getText().toString()));
                    dialog.dismiss();
                } else {
                    Toast.makeText(MainActivity.this, "Player name cannot be empty", Toast.LENGTH_SHORT).show();
                }
            });
        });

        dialog.show();
    }

    private void showPlayerDialog(String playerName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_player_details, null);
        builder.setView(dialogView);

        TextView playerNameTextView = dialogView.findViewById(R.id.textViewPlayerName);
        TextView levelTextView = dialogView.findViewById(R.id.textViewLevel);
        TextView trophiesTextView = dialogView.findViewById(R.id.textViewTrophies);
        TextView leagueTextView = dialogView.findViewById(R.id.textViewLeague);
        TextView positionTextView = dialogView.findViewById(R.id.textViewPosition);
        TextView isActiveTextView = dialogView.findViewById(R.id.textViewIsActive);
        TextView goldTextView = dialogView.findViewById(R.id.textViewGold);

        Player player = getPlayerDetails(playerName);
        playerNameTextView.setText("Player Name: " + player.getName());
        levelTextView.setText("Level: " + String.valueOf(player.getLevel()));
        trophiesTextView.setText("Trophies: " + String.valueOf(player.getTrophies()));
        leagueTextView.setText("League: " + player.getLeague());
        positionTextView.setText("Position: " + player.getPosition());
        isActiveTextView.setText("Active: " + String.valueOf(player.getIsActive()));
        goldTextView.setText("Gold: " + String.valueOf(player.getGold()));

        builder.setPositiveButton("Close", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private Player getPlayerDetails(String playerName) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                DatabaseContract.PlayerEntry.COLUMN_NAME_PLAYER_NAME,
                DatabaseContract.PlayerEntry.COLUMN_NAME_LEVEL,
                DatabaseContract.PlayerEntry.COLUMN_NAME_TROPHIES,
                DatabaseContract.PlayerEntry.COLUMN_NAME_LEAGUE,
                DatabaseContract.PlayerEntry.COLUMN_NAME_POSITION,
                DatabaseContract.PlayerEntry.COLUMN_NAME_IS_ACTIVE,
                DatabaseContract.PlayerEntry.COLUMN_NAME_GOLD
        };
        String selection = DatabaseContract.PlayerEntry.COLUMN_NAME_PLAYER_NAME + " = ?";
        String[] selectionArgs = { playerName };
        Cursor cursor = db.query(
                DatabaseContract.PlayerEntry.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );
        Player player = new Player();
        if (cursor.moveToFirst()) {
            player.setName(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.PlayerEntry.COLUMN_NAME_PLAYER_NAME)));
            player.setLevel(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseContract.PlayerEntry.COLUMN_NAME_LEVEL)));
            player.setTrophies(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseContract.PlayerEntry.COLUMN_NAME_TROPHIES)));
            player.setLeague(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.PlayerEntry.COLUMN_NAME_LEAGUE)));
            player.setPosition(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.PlayerEntry.COLUMN_NAME_POSITION)));
            player.setIsActive(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.PlayerEntry.COLUMN_NAME_IS_ACTIVE)));
            player.setGold(cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseContract.PlayerEntry.COLUMN_NAME_GOLD)));
        }
        cursor.close();
        return player;
    }

    private void insertPlayer(String playerName, int level, int trophies, String league, String position, String isActive, double gold) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseContract.PlayerEntry.COLUMN_NAME_PLAYER_NAME, playerName);
        values.put(DatabaseContract.PlayerEntry.COLUMN_NAME_LEVEL, level);
        values.put(DatabaseContract.PlayerEntry.COLUMN_NAME_TROPHIES, trophies);
        values.put(DatabaseContract.PlayerEntry.COLUMN_NAME_LEAGUE, league);
        values.put(DatabaseContract.PlayerEntry.COLUMN_NAME_POSITION, position);
        values.put(DatabaseContract.PlayerEntry.COLUMN_NAME_IS_ACTIVE, isActive);
        values.put(DatabaseContract.PlayerEntry.COLUMN_NAME_GOLD, gold);

        long newRowId = db.insert(DatabaseContract.PlayerEntry.TABLE_NAME, null, values);

        if (newRowId != -1) {
            Toast.makeText(this, "Player added successfully!", Toast.LENGTH_SHORT).show();
            loadPlayerData();
        } else {
            Toast.makeText(this, "Failed to add player!", Toast.LENGTH_SHORT).show();
        }
    }

    private void showUpdatePlayerDialog(String playerName) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.add_player_dialog, null);
        dialogBuilder.setView(dialogView);

        final EditText playerNameEditText = dialogView.findViewById(R.id.editTextPlayerName);
        final EditText levelEditText = dialogView.findViewById(R.id.editTextLevel);
        final EditText trophiesEditText = dialogView.findViewById(R.id.editTextTrophies);
        final EditText leagueEditText = dialogView.findViewById(R.id.editTextLeague);
        final EditText positionEditText = dialogView.findViewById(R.id.editTextPosition);
        final ToggleButton isActiveEditText = dialogView.findViewById(R.id.editTextIsActive);
        final EditText goldEditText = dialogView.findViewById(R.id.editTextGold);

        Player player = getPlayerDetails(playerName);

        playerNameEditText.setText(player.getName());
        levelEditText.setText(String.valueOf(player.getLevel()));
        trophiesEditText.setText( String.valueOf(player.getTrophies()));
        leagueEditText.setText(player.getLeague());
        positionEditText.setText(player.getPosition());
        isActiveEditText.setText(String.valueOf(player.getIsActive()));
        goldEditText.setText(String.valueOf(player.getGold()));


        dialogBuilder.setTitle("Update Player");
        dialogBuilder.setPositiveButton("Update", null);
        dialogBuilder.setNegativeButton("Cancel", null);

        final AlertDialog dialog = dialogBuilder.create();

        dialog.setOnShowListener(dialogInterface -> {
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            String[] projection = {
                    DatabaseContract.PlayerEntry.COLUMN_NAME_LEVEL,
                    DatabaseContract.PlayerEntry.COLUMN_NAME_TROPHIES,
                    DatabaseContract.PlayerEntry.COLUMN_NAME_LEAGUE,
                    DatabaseContract.PlayerEntry.COLUMN_NAME_POSITION,
                    DatabaseContract.PlayerEntry.COLUMN_NAME_IS_ACTIVE,
                    DatabaseContract.PlayerEntry.COLUMN_NAME_GOLD
            };
            String selection = DatabaseContract.PlayerEntry.COLUMN_NAME_PLAYER_NAME + " = ?";
            String[] selectionArgs = { playerName };
            Cursor cursor = db.query(
                    DatabaseContract.PlayerEntry.TABLE_NAME,
                    projection,
                    selection,
                    selectionArgs,
                    null,
                    null,
                    null
            );
            if (cursor.moveToFirst()) {
                levelEditText.setText(String.valueOf(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseContract.PlayerEntry.COLUMN_NAME_LEVEL))));
                trophiesEditText.setText(String.valueOf(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseContract.PlayerEntry.COLUMN_NAME_TROPHIES))));
                leagueEditText.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.PlayerEntry.COLUMN_NAME_LEAGUE)));
                positionEditText.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.PlayerEntry.COLUMN_NAME_POSITION)));
                isActiveEditText.setText(String.valueOf(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseContract.PlayerEntry.COLUMN_NAME_IS_ACTIVE))));
                goldEditText.setText(String.valueOf(cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseContract.PlayerEntry.COLUMN_NAME_GOLD))));
            }
            cursor.close();
        });

        dialog.setOnShowListener(dialogInterface -> {
            Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            positiveButton.setOnClickListener(view -> {
                String newName = playerNameEditText.getText().toString().trim();
                if (!newName.isEmpty()) {
                    updatePlayer(playerName,
                            newName,
                            Integer.parseInt(levelEditText.getText().toString()),
                            Integer.parseInt(trophiesEditText.getText().toString()),
                            leagueEditText.getText().toString(),
                            positionEditText.getText().toString(),
                            isActiveEditText.getText().toString(),
                            Double.parseDouble(goldEditText.getText().toString()));
                    dialog.dismiss();
                } else {
                    Toast.makeText(MainActivity.this, "Player name cannot be empty", Toast.LENGTH_SHORT).show();
                }
            });
        });

        dialog.show();
    }

    private void updatePlayer(String oldName, String newName, int level, int trophies, String league, String position, String isActive, double gold) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseContract.PlayerEntry.COLUMN_NAME_PLAYER_NAME, newName);
        values.put(DatabaseContract.PlayerEntry.COLUMN_NAME_LEVEL, level);
        values.put(DatabaseContract.PlayerEntry.COLUMN_NAME_TROPHIES, trophies);
        values.put(DatabaseContract.PlayerEntry.COLUMN_NAME_LEAGUE, league);
        values.put(DatabaseContract.PlayerEntry.COLUMN_NAME_POSITION, position);
        values.put(DatabaseContract.PlayerEntry.COLUMN_NAME_IS_ACTIVE, isActive);
        values.put(DatabaseContract.PlayerEntry.COLUMN_NAME_GOLD, gold);

        String selection = DatabaseContract.PlayerEntry.COLUMN_NAME_PLAYER_NAME + " = ?";
        String[] selectionArgs = { oldName };

        int count = db.update(
                DatabaseContract.PlayerEntry.TABLE_NAME,
                values,
                selection,
                selectionArgs);

        if (count > 0) {
            Toast.makeText(this, "Player updated successfully!", Toast.LENGTH_SHORT).show();
            loadPlayerData();
        } else {
            Toast.makeText(this, "Failed to update player!", Toast.LENGTH_SHORT).show();
        }
    }

    private void showConfirmDeleteDialog(String playerName) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setTitle("Confirm Delete");
        dialogBuilder.setMessage("Are you sure you want to delete this player?");
        dialogBuilder.setPositiveButton("Confirm", (dialog, which) -> deletePlayer(playerName));
        dialogBuilder.setNegativeButton("Cancel", null);
        dialogBuilder.create().show();
    }

    private void deletePlayer(String playerName) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String selection = DatabaseContract.PlayerEntry.COLUMN_NAME_PLAYER_NAME + " = ?";
        String[] selectionArgs = { playerName };

        int count = db.delete(
                DatabaseContract.PlayerEntry.TABLE_NAME,
                selection,
                selectionArgs);

        if (count > 0) {
            Toast.makeText(this, "Player deleted successfully!", Toast.LENGTH_SHORT).show();
            loadPlayerData();
        } else {
            Toast.makeText(this, "Failed to delete player!", Toast.LENGTH_SHORT).show();
        }
    }
}


