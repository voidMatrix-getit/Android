package voidy.sahil.exercises.files;

import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);
        textView = findViewById(R.id.textView);
    }

    public void writeData(View view) {
        String data = editText.getText().toString();
        if (data.isEmpty()) {
            Toast.makeText(this, "Please enter data to write", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            FileOutputStream fos = new FileOutputStream(new File("/sdcard","data.txt"));
            fos.write(data.getBytes());
            fos.close();
            Toast.makeText(this, "Data written to file successfully", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error writing data to file", Toast.LENGTH_SHORT).show();
        }
    }

    public void readData(View view) {
        try {
            FileInputStream isr = new FileInputStream(new File("/sdcard","data.txt"));
            BufferedReader br = new BufferedReader(new InputStreamReader(isr));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append("\n");
            }
            isr.close();
            textView.setText(sb.toString());
            Toast.makeText(this, "Data read from file", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error reading data from file", Toast.LENGTH_SHORT).show();
        }
    }
}
