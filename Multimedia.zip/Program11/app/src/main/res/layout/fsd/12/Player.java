package voidy.sahil.exercises.database;

public class Player {
    private String name;
    private int level;
    private int trophies;
    private String league;
    private String position;
    private String isActive;
    private double gold;


    public Player() {
    }

    public Player(String name, int level, int trophies, String league, String position, String isActive, double gold) {
        this.name = name;
        this.level = level;
        this.trophies = trophies;
        this.league = league;
        this.position = position;
        this.isActive = isActive;
        this.gold = gold;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getTrophies() {
        return trophies;
    }

    public void setTrophies(int trophies) {
        this.trophies = trophies;
    }

    public String getLeague() {
        return league;
    }

    public void setLeague(String league) {
        this.league = league;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    public double getGold() {
        return gold;
    }

    public void setGold(double gold) {
        this.gold = gold;
    }
}
